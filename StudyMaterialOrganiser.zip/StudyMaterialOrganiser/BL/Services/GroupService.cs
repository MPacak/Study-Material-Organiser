﻿using AutoMapper;
using BL.IServices;
using BL.Models;
using DAL.IRepositories;
using DAL.Models;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Configuration;
using System.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace BL.Services;

public class GroupService : IGroupService
{
	private readonly IUnitOfWork _unitOfWork;
	private readonly IMapper _groupMapper;
	private readonly ILogService _logService;


	public GroupService(IUnitOfWork unitOfWork, IConfiguration configuration, IMapper GroupMapper, ILogService logService)
	{
		_unitOfWork = unitOfWork;
		_groupMapper = GroupMapper;
		_logService = logService;
	
	}
	public ICollection<GroupDto> GetAll()
	{
		var allGroups = _unitOfWork.Group.GetAll(includeProperties: "Type,Image");
		_logService.Log("info", "All Groups were Fetched");
		return _groupMapper.Map<ICollection<GroupDto>>(allGroups).ToList();
	}


	public GroupDto? GetById(int id)
	{
		var requestedGroup = _unitOfWork.Group.GetFirstOrDefault(p => p.Id == id);
		_logService.Log("info", "Group with id " + id + " was Fetched");
		return requestedGroup == null ? null : _groupMapper.Map<GroupDto>(requestedGroup);

	}

	public GroupDto? Create(GroupDto Group)
	{
		var existingGroup = _unitOfWork.Group.GetFirstOrDefault(u => u.Name == Group.Name);
		if (existingGroup != null)
		{
			_logService.Log("error", "Group with name " + Group.Name + " already exists and could not be created");
			throw new InvalidOperationException("Group already exists");
		}


		var newGroup = _groupMapper.Map<Group>(Group);
	
		var users = _unitOfWork.User.GetAll(u => Group.Users.Contains(u.Username));
		newGroup.GroupSkills = skills.Select(s => new GroupSkill
		{
			Group = newGroup,
			Skill = s
		}).ToList();
		newGroup.Applications = users.Select(u => new Application
		{
			Group = newGroup,
			User = u
		}).ToList();



		_unitOfWork.Group.Add(newGroup);
		_unitOfWork.Save();
		_logService.Log("info", "Group with name " + Group.Name + " was Created");
		return _groupMapper.Map<GroupDto>(newGroup);

	}
	public GroupDto? Update(int id, GroupDto Group)
	{
		var GroupForUpdate = _unitOfWork.Group.GetFirstOrDefault(p => p.Id == id, "GroupSkills.Skill");
		if (GroupForUpdate == null) return null;


		GroupForUpdate.Name = Group.Name;
		GroupForUpdate.Description = Group.Description;
		GroupForUpdate.TypeId = Group.TypeId;
		GroupForUpdate.ImageId = Group.ImageId;
		GroupForUpdate.StartDate = Group.StartDate;
		GroupForUpdate.EndDate = Group.EndDate;

		var existingSkills = GroupForUpdate.GroupSkills.ToList();

		var GroupSkillsToRemove = existingSkills
			.Where(ps => !Group.Skills.Contains(ps.Skill.Name))
			.ToList();

		foreach (var GroupSkill in GroupSkillsToRemove)
		{
			_unitOfWork.GroupSkills.Delete(GroupSkill);
		}

		var newSkillNames = Group.Skills
			.Except(existingSkills.Select(ps => ps.Skill.Name))
			.ToList();

		foreach (var newSkillName in newSkillNames)
		{
			var skillFromDb = _unitOfWork.Skill.GetFirstOrDefault(s => s.Name == newSkillName);
			if (skillFromDb == null) continue;

			GroupForUpdate.GroupSkills.Add(new GroupSkill
			{
				Group = GroupForUpdate,
				Skill = skillFromDb
			});
		}

		_unitOfWork.Save();

		_logService.Log("info", "Group with name " + Group.Name + " was Updated");
		return _groupMapper.Map<GroupDto>(GroupForUpdate);
	}


	public GroupDto? Delete(int id)
	{
		var toDelete = _unitOfWork.Group.GetFirstOrDefault(p => p.Id == id);
		if (toDelete == null) return null;

		var GroupSkills = _unitOfWork.GroupSkills.GetAll(ps => ps.GroupId == id);
		foreach (var GroupSkill in GroupSkills)
		{
			_unitOfWork.GroupSkills.Delete(GroupSkill);
		}

		var applications = _unitOfWork.Application.GetAll(a => a.GroupId == id);
		foreach (var application in applications)
		{
			_unitOfWork.Application.Delete(application);
		}

		_unitOfWork.Group.Delete(toDelete);
		_unitOfWork.Save();
		_logService.Log("info", "Group with name " + toDelete.Name + " was Deleted");
		return _groupMapper.Map<GroupDto>(toDelete);
	}

	public IEnumerable<GroupDto> GetPaged(int page, int size)
	{

		var allGroups = _unitOfWork.Group.GetAll();
		var pagedGroups = allGroups.Skip((page - 1) * size).Take(size);
		var GroupDtos = _groupMapper.Map<IEnumerable<GroupDto>>(pagedGroups);
		foreach (var Group in GroupDtos)
		{
			Group.Typename = _typeService.GetById(Group.TypeId).Name.ToString();
		}
		_logService.Log("info", "All Groups were Fetched");
		return GroupDtos;


	}

	public int GetCount() => _unitOfWork.Group.GetAll().Count();


	public IEnumerable<GroupDto> GetFiltered(IEnumerable<GroupDto> Groups, string? filterBy, string? filter)
	{
		filter = filter?.ToLower();

		if (string.IsNullOrWhiteSpace(filter) || string.IsNullOrWhiteSpace(filterBy))
		{
			foreach (var Group in Groups)
			{
				Group.Typename = _typeService.GetById(Group.TypeId).ToString();
			}
			return Groups;
		}

		var filterMap = new Dictionary<string, Func<GroupDto, string>>()
		{

			{ "name", u => u.Name },
			{ "description", u => u.Description.ToString() },
			{ "type", u => u.Typename.ToString() }



	};

		if (filterMap.TryGetValue(filterBy.ToLower(), out var filterFunc))
		{
			Groups = Groups.Where(u => filterFunc(u).ToLower().Contains(filter));
		}

		return Groups;
	}

	public PaginatedResponse<GroupDto> Search(int size, int page, string? filterNames)
	{
		if (size <= 0) size = 10;
		if (page < 0) page = 0;

		var Groups = _unitOfWork.Group.GetAll();

		if (!string.IsNullOrEmpty(filterNames))
		{
			Groups = Groups.Where(p => p.Name.Contains(filterNames));
		}

		var totalItems = Groups.Count();
		var pagedGroups = Groups.Skip(size * page).Take(size).ToList();

		var GroupDtos = _groupMapper.Map<IEnumerable<GroupDto>>(pagedGroups);

		return new PaginatedResponse<GroupDto>
		{
			Items = GroupDtos,
			TotalCount = totalItems,
			Page = page,
			PageSize = size
		};
	}
}